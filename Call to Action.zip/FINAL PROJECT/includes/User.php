<?php
require_once 'config.php';
require_once 'db.php';

class User {
    private $db;
    private $userData;

    public function __construct() {
        $this->db = new Database();
        $this->userData = isset($_SESSION['user']) ? $_SESSION['user'] : null;
    }

    public function register($data) {
        // Validate input
        if (empty($data['username']) || empty($data['email']) || empty($data['password'])) {
            return ['success' => false, 'message' => 'All fields are required'];
        }

        // Check if username or email already exists
        if ($this->db->fetch("SELECT id FROM users WHERE username = ? OR email = ?", 
            [$data['username'], $data['email']])) {
            return ['success' => false, 'message' => 'Username or email already exists'];
        }

        // Hash password
        $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);

        // Insert user
        $userData = [
            'username' => $data['username'],
            'email' => $data['email'],
            'password' => $hashedPassword,
            'role' => 'user',
            'created_at' => date('Y-m-d H:i:s')
        ];

        $userId = $this->db->insert('users', $userData);

        if ($userId) {
            return ['success' => true, 'message' => 'Registration successful'];
        }

        return ['success' => false, 'message' => 'Registration failed'];
    }

    public function login($username, $password) {
        $user = $this->db->fetch("SELECT * FROM users WHERE username = ?", [$username]);

        if ($user && password_verify($password, $user['password'])) {
            // Update last login
            $this->db->update('users', 
                ['last_login' => date('Y-m-d H:i:s')], 
                'id = ?', 
                [$user['id']]
            );

            // Set session
            $_SESSION['user'] = $user;
            $this->userData = $user;

            return ['success' => true, 'message' => 'Login successful'];
        }

        return ['success' => false, 'message' => 'Invalid username or password'];
    }

    public function logout() {
        unset($_SESSION['user']);
        $this->userData = null;
        session_destroy();
        return true;
    }

    public function isLoggedIn() {
        return !is_null($this->userData);
    }

    public function isAdmin() {
        return $this->isLoggedIn() && $this->userData['role'] === 'admin';
    }

    public function getUserId() {
        return $this->isLoggedIn() ? $this->userData['id'] : null;
    }

    public function getUserData() {
        return $this->userData;
    }

    public function updateProfile($data) {
        if (!$this->isLoggedIn()) {
            return ['success' => false, 'message' => 'Not logged in'];
        }

        $updateData = [];
        
        if (!empty($data['email'])) {
            $updateData['email'] = $data['email'];
        }
        
        if (!empty($data['password'])) {
            $updateData['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        }

        if (!empty($updateData)) {
            $success = $this->db->update('users', 
                $updateData, 
                'id = ?', 
                [$this->getUserId()]
            );

            if ($success) {
                // Update session data
                $this->userData = array_merge($this->userData, $updateData);
                $_SESSION['user'] = $this->userData;
                
                return ['success' => true, 'message' => 'Profile updated successfully'];
            }
        }

        return ['success' => false, 'message' => 'Failed to update profile'];
    }

    public function deleteAccount() {
        if (!$this->isLoggedIn()) {
            return ['success' => false, 'message' => 'Not logged in'];
        }

        $success = $this->db->delete('users', 'id = ?', [$this->getUserId()]);

        if ($success) {
            $this->logout();
            return ['success' => true, 'message' => 'Account deleted successfully'];
        }

        return ['success' => false, 'message' => 'Failed to delete account'];
    }
}
?> 