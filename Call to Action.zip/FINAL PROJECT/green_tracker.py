import tkinter as tk
from tkinter import ttk, messagebox
import json
import datetime
from PIL import Image, ImageTk
import random
import hashlib

class UserManager:
    def __init__(self):
        self.users_file = "users.json"
        self.load_users()

    def load_users(self):
        try:
            with open(self.users_file, "r") as f:
                self.users = json.load(f)
        except FileNotFoundError:
            self.users = {}
            self.save_users()

    def save_users(self):
        with open(self.users_file, "w") as f:
            json.dump(self.users, f)

    def register_user(self, username, password):
        if username in self.users:
            return False, "Username already exists"
        
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        self.users[username] = {
            "password": hashed_password,
            "points": 0,
            "streak": 0,
            "last_checkin": None,
            "completed_actions": [],
            "action_history": []
        }
        self.save_users()
        return True, "User registered successfully"

    def login_user(self, username, password):
        if username not in self.users:
            return False, "User not found"
        
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        if self.users[username]["password"] != hashed_password:
            return False, "Incorrect password"
        
        return True, "Login successful"

class GreenTracker:
    def __init__(self, root):
        self.root = root
        self.root.title("🌱 Green Earth Tracker")
        self.root.geometry("800x600")
        self.root.configure(bg="#f0f8f0")
        
        self.user_manager = UserManager()
        self.current_user = None
        
        # Create main frame
        self.main_frame = ttk.Frame(root, padding="20")
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Show login screen first
        self.show_login_screen()

    def show_login_screen(self):
        # Clear main frame
        for widget in self.main_frame.winfo_children():
            widget.destroy()
        
        login_frame = ttk.Frame(self.main_frame)
        login_frame.pack(expand=True)
        
        ttk.Label(
            login_frame,
            text="🌍 Green Earth Tracker",
            font=("Helvetica", 24, "bold"),
            foreground="#2e8b57"
        ).pack(pady=20)
        
        # Username
        ttk.Label(login_frame, text="Username:").pack()
        self.username_entry = ttk.Entry(login_frame)
        self.username_entry.pack(pady=5)
        
        # Password
        ttk.Label(login_frame, text="Password:").pack()
        self.password_entry = ttk.Entry(login_frame, show="*")
        self.password_entry.pack(pady=5)
        
        # Buttons
        button_frame = ttk.Frame(login_frame)
        button_frame.pack(pady=20)
        
        ttk.Button(
            button_frame,
            text="Login",
            command=self.login
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Register",
            command=self.show_register_screen
        ).pack(side=tk.LEFT, padx=5)

    def show_register_screen(self):
        # Clear main frame
        for widget in self.main_frame.winfo_children():
            widget.destroy()
        
        register_frame = ttk.Frame(self.main_frame)
        register_frame.pack(expand=True)
        
        ttk.Label(
            register_frame,
            text="Register New User",
            font=("Helvetica", 20, "bold"),
            foreground="#2e8b57"
        ).pack(pady=20)
        
        # Username
        ttk.Label(register_frame, text="Username:").pack()
        self.reg_username_entry = ttk.Entry(register_frame)
        self.reg_username_entry.pack(pady=5)
        
        # Password
        ttk.Label(register_frame, text="Password:").pack()
        self.reg_password_entry = ttk.Entry(register_frame, show="*")
        self.reg_password_entry.pack(pady=5)
        
        # Buttons
        button_frame = ttk.Frame(register_frame)
        button_frame.pack(pady=20)
        
        ttk.Button(
            button_frame,
            text="Register",
            command=self.register
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Back to Login",
            command=self.show_login_screen
        ).pack(side=tk.LEFT, padx=5)

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        
        success, message = self.user_manager.login_user(username, password)
        if success:
            self.current_user = username
            self.show_main_screen()
        else:
            messagebox.showerror("Login Failed", message)

    def register(self):
        username = self.reg_username_entry.get()
        password = self.reg_password_entry.get()
        
        success, message = self.user_manager.register_user(username, password)
        if success:
            messagebox.showinfo("Success", message)
            self.show_login_screen()
        else:
            messagebox.showerror("Registration Failed", message)

    def show_main_screen(self):
        # Clear main frame
        for widget in self.main_frame.winfo_children():
            widget.destroy()
        
        # Create header
        self.create_header()
        
        # Create points display
        self.create_points_display()
        
        # Create actions frame
        self.create_actions_frame()
        
        # Create progress section
        self.create_progress_section()
        
        # Create achievements section
        self.create_achievements_section()
        
        # Create admin button if current user is admin
        if self.current_user == "admin":
            ttk.Button(
                self.main_frame,
                text="View All Users",
                command=self.show_admin_dashboard
            ).pack(pady=10)
        
        # Update UI
        self.update_ui()

    def show_admin_dashboard(self):
        admin_window = tk.Toplevel(self.root)
        admin_window.title("Admin Dashboard")
        admin_window.geometry("600x400")
        
        # Create treeview for user data
        tree = ttk.Treeview(admin_window, columns=("Username", "Points", "Streak", "Actions"))
        tree.heading("#0", text="ID")
        tree.heading("Username", text="Username")
        tree.heading("Points", text="Points")
        tree.heading("Streak", text="Streak")
        tree.heading("Actions", text="Completed Actions")
        
        # Add user data
        for i, (username, data) in enumerate(self.user_manager.users.items()):
            if username != "admin":  # Skip admin user
                tree.insert("", "end", text=str(i+1), values=(
                    username,
                    data["points"],
                    data["streak"],
                    len(data["completed_actions"])
                ))
        
        tree.pack(fill=tk.BOTH, expand=True)

    def create_header(self):
        header_frame = ttk.Frame(self.main_frame)
        header_frame.pack(fill=tk.X, pady=10)
        
        title_label = ttk.Label(
            header_frame,
            text=f"🌍 Welcome, {self.current_user}!",
            font=("Helvetica", 24, "bold"),
            foreground="#2e8b57"
        )
        title_label.pack(side=tk.LEFT)
        
        logout_button = ttk.Button(
            header_frame,
            text="Logout",
            command=self.logout
        )
        logout_button.pack(side=tk.RIGHT)

    def logout(self):
        self.current_user = None
        self.show_login_screen()

    def create_points_display(self):
        points_frame = ttk.Frame(self.main_frame)
        points_frame.pack(fill=tk.X, pady=20)
        
        user_data = self.user_manager.users[self.current_user]
        
        self.points_label = ttk.Label(
            points_frame,
            text=f"🌱 Points: {user_data['points']}",
            font=("Helvetica", 18, "bold"),
            foreground="#2e8b57"
        )
        self.points_label.pack()
        
        streak_label = ttk.Label(
            points_frame,
            text=f"🔥 Streak: {user_data['streak']} days",
            font=("Helvetica", 14),
            foreground="#ff8c00"
        )
        streak_label.pack()

    def create_actions_frame(self):
        actions_frame = ttk.LabelFrame(
            self.main_frame,
            text="Daily Sustainable Actions",
            padding="10"
        )
        actions_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.actions = [
            {
                "name": "Turned off lights when not in use",
                "points": 5,
                "category": "Energy",
                "description": "Reducing electricity usage by turning off lights when not needed",
                "completed": False
            },
            {
                "name": "Used public transport or carpool",
                "points": 15,
                "category": "Transport",
                "description": "Reducing carbon emissions by using shared transportation",
                "completed": False
            },
            {
                "name": "Shortened shower time",
                "points": 10,
                "category": "Water",
                "description": "Conserving water by reducing shower time",
                "completed": False
            },
            {
                "name": "Used reusable water bottle",
                "points": 8,
                "category": "Waste",
                "description": "Reducing plastic waste by using a reusable bottle",
                "completed": False
            },
            {
                "name": "Recycled plastic and paper",
                "points": 12,
                "category": "Waste",
                "description": "Properly recycling materials to reduce landfill waste",
                "completed": False
            },
            {
                "name": "Used reusable shopping bags",
                "points": 7,
                "category": "Waste",
                "description": "Reducing plastic bag usage by using reusable bags",
                "completed": False
            },
            {
                "name": "Air-dried clothes",
                "points": 10,
                "category": "Energy",
                "description": "Saving energy by air-drying clothes instead of using a dryer",
                "completed": False
            }
        ]
        
        # Load completed actions for current user
        user_data = self.user_manager.users[self.current_user]
        for action in self.actions:
            if action["name"] in user_data["completed_actions"]:
                action["completed"] = True
        
        # Create category tabs
        self.tab_control = ttk.Notebook(actions_frame)
        
        # Create tabs for each category
        energy_tab = ttk.Frame(self.tab_control)
        water_tab = ttk.Frame(self.tab_control)
        waste_tab = ttk.Frame(self.tab_control)
        transport_tab = ttk.Frame(self.tab_control)
        
        self.tab_control.add(energy_tab, text='Energy')
        self.tab_control.add(water_tab, text='Water')
        self.tab_control.add(waste_tab, text='Waste')
        self.tab_control.add(transport_tab, text='Transport')
        
        self.tab_control.pack(expand=1, fill='both')
        
        # Organize actions by category
        action_categories = {
            'Energy': energy_tab,
            'Water': water_tab,
            'Waste': waste_tab,
            'Transport': transport_tab
        }
        
        # Create action frames for each category
        for action in self.actions:
            category_frame = action_categories[action['category']]
            action_frame = ttk.Frame(category_frame)
            action_frame.pack(fill=tk.X, pady=5)
            
            # Create action description frame
            desc_frame = ttk.Frame(action_frame)
            desc_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
            
            # Action name and checkbox
            action_check = ttk.Checkbutton(
                desc_frame,
                text=action["name"],
                command=lambda a=action: self.toggle_action(a)
            )
            action_check.pack(anchor=tk.W)
            
            if action["completed"]:
                action_check.state(['selected'])
            
            # Points and description
            points_frame = ttk.Frame(action_frame)
            points_frame.pack(side=tk.RIGHT)
            
            points_label = ttk.Label(
                points_frame,
                text=f"+{action['points']} points",
                foreground="#2e8b57"
            )
            points_label.pack()
            
            desc_label = ttk.Label(
                points_frame,
                text=action["description"],
                wraplength=200,
                font=("Helvetica", 8)
            )
            desc_label.pack()

    def toggle_action(self, action):
        action["completed"] = not action["completed"]
        user_data = self.user_manager.users[self.current_user]
        
        if action["completed"]:
            user_data["points"] += action["points"]
            user_data["completed_actions"].append(action["name"])
            user_data["action_history"].append({
                "action": action["name"],
                "points": action["points"],
                "date": datetime.datetime.now().strftime("%Y-%m-%d")
            })
        else:
            user_data["points"] -= action["points"]
            user_data["completed_actions"].remove(action["name"])
        
        self.user_manager.save_users()
        self.update_ui()
        
        if action["completed"]:
            messagebox.showinfo(
                "Great Job!",
                f"You earned {action['points']} points for {action['name']}!"
            )

    def create_progress_section(self):
        progress_frame = ttk.LabelFrame(
            self.main_frame,
            text="Weekly Progress",
            padding="10"
        )
        progress_frame.pack(fill=tk.X, pady=10)
        
        # Create progress bars for each category
        self.progress_bars = {}
        categories = ["Energy", "Water", "Waste", "Transport"]
        
        for category in categories:
            category_frame = ttk.Frame(progress_frame)
            category_frame.pack(fill=tk.X, pady=5)
            
            ttk.Label(
                category_frame,
                text=f"{category} Progress:",
                font=("Helvetica", 10, "bold")
            ).pack(side=tk.LEFT)
            
            self.progress_bars[category] = {
                "bar": ttk.Progressbar(
                    category_frame,
                    orient=tk.HORIZONTAL,
                    length=200,
                    mode='determinate'
                ),
                "label": ttk.Label(
                    category_frame,
                    text="0% Complete",
                    font=("Helvetica", 10)
                )
            }
            
            self.progress_bars[category]["bar"].pack(side=tk.LEFT, padx=10)
            self.progress_bars[category]["label"].pack(side=tk.LEFT)

    def update_ui(self):
        user_data = self.user_manager.users[self.current_user]
        self.points_label.config(text=f"🌱 Points: {user_data['points']}")
        
        # Update progress bars for each category
        category_points = {
            "Energy": 0,
            "Water": 0,
            "Waste": 0,
            "Transport": 0
        }
        
        # Calculate points for each category
        for action in self.actions:
            if action["completed"]:
                category_points[action["category"]] += action["points"]
        
        # Update progress bars
        for category, points in category_points.items():
            total_possible = sum(
                a["points"] for a in self.actions if a["category"] == category
            )
            if total_possible > 0:
                progress = (points / total_possible) * 100
                self.progress_bars[category]["bar"]["value"] = progress
                self.progress_bars[category]["label"].config(
                    text=f"{int(progress)}% Complete"
                )

    def create_achievements_section(self):
        achievements_frame = ttk.LabelFrame(
            self.main_frame,
            text="Achievements",
            padding="10"
        )
        achievements_frame.pack(fill=tk.X, pady=10)
        
        achievements = [
            "🌱 Green Beginner (100 points)",
            "⚡ Energy Saver (200 energy points)",
            "💧 Water Warrior (150 water points)",
            "♻️ Recycling Master (250 waste points)",
            "🌍 Earth Guardian (500 total points)"
        ]
        
        for achievement in achievements:
            ttk.Label(
                achievements_frame,
                text=achievement,
                font=("Helvetica", 12)
            ).pack(anchor=tk.W)

if __name__ == "__main__":
    root = tk.Tk()
    app = GreenTracker(root)
    root.mainloop()