<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Us - EcoSmart</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Us - EcoSmart</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ... existing styles ... */
        .error-message {
            color: #ff0000;
            font-size: 0.9em;
            margin-top: 5px;
            display: none;
        }
        .success-message {
            color: #4CAF50;
            font-size: 0.9em;
            margin-top: 5px;
            display: none;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <a href="Call to Action Project.html">EcoSmart</a>
            </div>
        </div>
    </nav>

    <div class="form-container">
        <h2>Join EcoSmart</h2>
        <form id="registrationForm" action="process_form.php" method="POST" onsubmit="return validateForm()">
            <input type="text" name="full_name" placeholder="Full Name" required>
            <div class="error-message" id="nameError"></div>
            
            <input type="email" name="email" placeholder="Email" required>
            <div class="error-message" id="emailError"></div>
            
            <input type="password" name="password" placeholder="Create Password" required>
            <div class="error-message" id="passwordError"></div>
            
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <div class="error-message" id="confirmPasswordError"></div>
            
            <button type="submit">Sign Up</button>
        </form>
        <div class="login-link">
            Already have an account? <a href="Reference.html">Login</a>
        </div>
        <div class="back-link">
            <a href="Call to Action Project.html">← Back to Home</a>
        </div>
    </div>

    <script>
        function validateForm() {
            let isValid = true;
            const name = document.querySelector('input[name="full_name"]').value;
            const email = document.querySelector('input[name="email"]').value;
            const password = document.querySelector('input[name="password"]').value;
            const confirmPassword = document.querySelector('input[name="confirm_password"]').value;

            // Reset error messages
            document.querySelectorAll('.error-message').forEach(elem => {
                elem.style.display = 'none';
            });

            // Name validation
            if (name.length < 2) {
                document.getElementById('nameError').textContent = 'Name must be at least 2 characters long';
                document.getElementById('nameError').style.display = 'block';
                isValid = false;
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                document.getElementById('emailError').textContent = 'Please enter a valid email address';
                document.getElementById('emailError').style.display = 'block';
                isValid = false;
            }

            // Password validation
            if (password.length < 8) {
                document.getElementById('passwordError').textContent = 'Password must be at least 8 characters long';
                document.getElementById('passwordError').style.display = 'block';
                isValid = false;
            }

            // Confirm password validation
            if (password !== confirmPassword) {
                document.getElementById('confirmPasswordError').textContent = 'Passwords do not match';
                document.getElementById('confirmPasswordError').style.display = 'block';
                isValid = false;
            }

            return isValid;
        }
    </script>
</body>
</html>
    <style>
        :root {
            --primary-color: #2ecc71;
            --secondary-color: #27ae60;
            --dark-green: #219653;
            --light-green: #a8e6cf;
            --white: #ffffff;
            --gray: #f4f4f4;
            --dark: #333333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: var(--gray);
            color: var(--dark);
            line-height: 1.6;
        }

        .navbar {
            background-color: var(--white);
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }

        .logo a {
            color: var(--primary-color);
            font-size: 1.5rem;
            font-weight: 700;
            text-decoration: none;
        }

        .form-container {
            max-width: 500px;
            margin: 120px auto 40px;
            padding: 40px;
            background-color: var(--white);
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        h2 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
            font-size: 2rem;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 2px solid var(--light-green);
            border-radius: 5px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        input:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        button {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 12px;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        button:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
        }

        .login-link, .back-link {
            text-align: center;
            margin-top: 20px;
        }

        a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        a:hover {
            color: var(--secondary-color);
        }

        .back-link {
            margin-top: 30px;
        }

        .back-link a {
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        @media (max-width: 768px) {
            .form-container {
                margin: 100px 20px 40px;
                padding: 20px;
            }
        }

        .error-message {
            color: #ff0000;
            font-size: 0.9em;
            margin-top: 5px;
            display: none;
        }
        .success-message {
            color: #4CAF50;
            font-size: 0.9em;
            margin-top: 5px;
            display: none;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <a href="Call to Action Project.html">EcoSmart</a>
            </div>
        </div>
    </nav>

    <div class="form-container">
        <h2>Join EcoSmart</h2>
        <form id="registrationForm" action="process_form.php" method="POST" onsubmit="return validateForm()">
            <input type="text" name="full_name" placeholder="Full Name" required>
            <div class="error-message" id="nameError"></div>
            
            <input type="email" name="email" placeholder="Email" required>
            <div class="error-message" id="emailError"></div>
            
            <input type="password" name="password" placeholder="Create Password" required>
            <div class="error-message" id="passwordError"></div>
            
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <div class="error-message" id="confirmPasswordError"></div>
            
            <button type="submit">Sign Up</button>
        </form>
        <div class="login-link">
            Already have an account? <a href="Reference.html">Login</a>
        </div>
        <div class="back-link">
            <a href="Call to Action Project.html">← Back to Home</a>
        </div>
    </div>

    <script>
        function validateForm() {
            let isValid = true;
            const name = document.querySelector('input[name="full_name"]').value;
            const email = document.querySelector('input[name="email"]').value;
            const password = document.querySelector('input[name="password"]').value;
            const confirmPassword = document.querySelector('input[name="confirm_password"]').value;

            // Reset error messages
            document.querySelectorAll('.error-message').forEach(elem => {
                elem.style.display = 'none';
            });

            // Name validation
            if (name.length < 2) {
                document.getElementById('nameError').textContent = 'Name must be at least 2 characters long';
                document.getElementById('nameError').style.display = 'block';
                isValid = false;
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                document.getElementById('emailError').textContent = 'Please enter a valid email address';
                document.getElementById('emailError').style.display = 'block';
                isValid = false;
            }

            // Password validation
            if (password.length < 8) {
                document.getElementById('passwordError').textContent = 'Password must be at least 8 characters long';
                document.getElementById('passwordError').style.display = 'block';
                isValid = false;
            }

            // Confirm password validation
            if (password !== confirmPassword) {
                document.getElementById('confirmPasswordError').textContent = 'Passwords do not match';
                document.getElementById('confirmPasswordError').style.display = 'block';
                isValid = false;
            }

            return isValid;
        }
    </script>
</body>
</html>

